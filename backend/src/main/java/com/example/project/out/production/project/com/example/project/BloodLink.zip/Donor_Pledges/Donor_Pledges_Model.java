package com.example.project.Donor_Pledges;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.sql.Timestamp;
import com.example.project.Blood_Requests.Blood_Requests_Model;
import com.example.project.Donor_Profiles.Donor_Profiles_Model;

@Entity
public class Donor_Pledges_Model {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pledgeId;

    @NotBlank
    private String pledge_status;


    @Min(0)
    private int pledged_units;


    @NotBlank
    private String message;


    @PastOrPresent
    private Timestamp updated_at;


    @PastOrPresent
    private Timestamp created_at;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "donorId", nullable = false)
    private Donor_Profiles_Model donorProfile;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requestId")
    private Blood_Requests_Model matchedRequest;


    public Donor_Pledges_Model() {}

    public Donor_Pledges_Model(Long id, String status, int units, String message) {
        this.pledgeId = id;
        this.pledge_status = status;
        this.pledged_units = units;
        this.message = message;
        updated_at = new Timestamp(System.currentTimeMillis());
        created_at = new Timestamp(System.currentTimeMillis());
    }
    @PrePersist
    protected void onCreate() {
        if (created_at == null) created_at = new Timestamp(System.currentTimeMillis());
        if (updated_at == null) updated_at = new Timestamp(System.currentTimeMillis());
    }

    @PreUpdate
    protected void onUpdate() {
        updated_at = new Timestamp(System.currentTimeMillis());
    }

    public Long getPledgeId() { return pledgeId; }
    public void setPledgeId(Long pledgeId) { this.pledgeId = pledgeId; }
    public String getPledge_status() { return pledge_status; }
    public void setPledge_status(String pledge_status){ this.pledge_status = pledge_status; }
    public int getPledged_units() { return pledged_units; }
    public void setPledged_units(int pledged_units){ this.pledged_units = pledged_units; }
    public String getMessage() { return message; }
    public void setMessage(String message){ this.message = message; }
    public Timestamp getUpdated_at() { return updated_at; }
    public void setUpdated_at(Timestamp updated_at){ this.updated_at =  updated_at; }
    public Timestamp getCreatedAt() { return created_at; }
    public void setCreatedAt(Timestamp created_at) { this.created_at = created_at; }
}
