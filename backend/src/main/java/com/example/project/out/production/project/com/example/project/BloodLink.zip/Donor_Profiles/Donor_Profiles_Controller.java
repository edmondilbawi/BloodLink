package com.example.project.Donor_Profiles;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Donor_Profiles")
public class Donor_Profiles_Controller {

    private final Donor_Profiles_Repository repo;

    public Donor_Profiles_Controller(Donor_Profiles_Repository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Donor_Profiles_Model> all() {
        return repo.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Donor_Profiles_Model create(@Valid @RequestBody Donor_Profiles_Model donor) {
        return repo.save(donor);
    }

    @GetMapping("/{id}")
    public Donor_Profiles_Model getOne(@PathVariable Long id) {
        return repo.findById(id).orElseThrow();
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        repo.deleteById(id);
    }
}
