package com.example.project.Users;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/Users")
public class User_Controller {
    private final User_Repository repo;

    public User_Controller(User_Repository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<User_Model> all() {
        return repo.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public User_Model create(@Valid @RequestBody User_Model user) {
        return repo.save(user);
    }

    @DeleteMapping("/{user_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable("user_id") Long userId) {
        repo.deleteById(userId);
    }
}
