package com.example.project.Donor_Pledges;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Donor_Pledges_Repository  extends JpaRepository<Donor_Pledges_Model, Long> {
}
