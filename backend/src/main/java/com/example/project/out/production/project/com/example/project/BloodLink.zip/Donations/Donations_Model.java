package com.example.project.Donations;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.sql.Timestamp;
import com.example.project.Blood_Requests.Blood_Requests_Model;
import com.example.project.Donor_Profiles.Donor_Profiles_Model;

@Entity
public class Donations_Model {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long donationId;

    @Min(0)
    private int units_donated;


    @NotBlank
    private String outcome;


    @PastOrPresent
    private Timestamp donation_time;

    @NotNull
    private Boolean confirmed_by_requester;


    @PastOrPresent
    private Timestamp created_at;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "donorId", nullable = false)
    private Donor_Profiles_Model donorProfile;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requestId")
    private Blood_Requests_Model fulfilledRequest;


    public Donations_Model() {}

    public Donations_Model(Long id, int units_donated, String outcome, Boolean confirmed_by_requester) {
        this.donationId = id;
        this.units_donated = units_donated;
        this.outcome = outcome;
        created_at = new Timestamp(System.currentTimeMillis());
    }
    @PrePersist
    protected void onCreate() {
        if (created_at == null) created_at = new Timestamp(System.currentTimeMillis());
    }


    public Long getDonationId() { return donationId; }
    public void setDonationId(Long donationId) { this.donationId = donationId; }
    public int getUnits_donated() { return units_donated; }
    public void setUnits_donated(int units_donated) {this.units_donated = units_donated; }
    public String getOutcome() { return outcome; }
    public void setOutcome(String outcome) { this.outcome = outcome; }
    public Timestamp getDonation_time() { return donation_time; }
    public void setDonation_time(Timestamp donation_time) {this.donation_time = donation_time; }
    public Boolean getConfirmed_by_requester() { return confirmed_by_requester; }
    public void setConfirmed_by_requester(Boolean confirmed_by_requester) {this.confirmed_by_requester = confirmed_by_requester; }
    public Timestamp getCreated_at() { return created_at; }
    public void setCreated_at(Timestamp created_at) {this.created_at = created_at; }


}
