package com.example.project.Blood_Requests;

import com.example.project.Blood_Requests.Blood_Requests_Model;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Blood_Requests_Repository extends JpaRepository<Blood_Requests_Model, Long> {}
