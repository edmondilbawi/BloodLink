package com.example.project.Blood_Requests;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;
import com.example.project.Users.User_Model;

@Entity
@Table(name = "Blood_Requests")
public class    Blood_Requests_Model {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "request_id")
    private Long requestId;

    @NotBlank
    @Column(name = "needed_blood_type", length = 3, nullable = false)
    private String neededBloodType;   // "A", "B", "AB", "O"

    @NotBlank
    @Pattern(regexp = "[+-]", message = "needed_rhesus must be '+' or '-'")
    @Column(name = "needed_rhesus", length = 1, nullable = false)
    private String neededRhesus;      // "+" or "-"

    @Min(1)
    @Column(name = "units_needed", nullable = false)
    private int unitsNeeded;

    @NotBlank
    @Column(name = "hospital_name", nullable = false)
    private String hospitalName;

    @NotBlank
    @Column(name = "hospital_address", nullable = false)
    private String hospitalAddress;

    @NotBlank
    @Column(name = "urgency", nullable = false) // e.g., High/Medium/Low
    private String urgency;

    @NotBlank
    @Column(name = "status", nullable = false)  // e.g., Pending/Completed
    private String status;

    @FutureOrPresent
    @Column(name = "needed_before")
    private LocalDateTime neededBefore;

    @Column(name = "notes")
    private String notes;

    @PastOrPresent
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId", nullable = false)
    private User_Model requestedById;


    public Blood_Requests_Model() {}

    public Blood_Requests_Model(String neededBloodType, String neededRhesus, int unitsNeeded,
                        String hospitalName, String hospitalAddress,
                        String urgency, String status,
                        LocalDateTime neededBefore, String notes) {
        this.neededBloodType = neededBloodType;
        this.neededRhesus = neededRhesus;
        this.unitsNeeded = unitsNeeded;
        this.hospitalName = hospitalName;
        this.hospitalAddress = hospitalAddress;
        this.urgency = urgency;
        this.status = status;
        this.neededBefore = neededBefore;
        this.notes = notes;
        this.createdAt = LocalDateTime.now();
    }

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
    }

    // Getters/setters (standard names so JSON uses the same keys)
    public Long getRequestId() { return requestId; }
    public void setRequestId(Long requestId) { this.requestId = requestId; }

    public String getNeededBloodType() { return neededBloodType; }
    public void setNeededBloodType(String neededBloodType) { this.neededBloodType = neededBloodType; }

    public String getNeededRhesus() { return neededRhesus; }
    public void setNeededRhesus(String neededRhesus) { this.neededRhesus = neededRhesus; }

    public int getUnitsNeeded() { return unitsNeeded; }
    public void setUnitsNeeded(int unitsNeeded) { this.unitsNeeded = unitsNeeded; }

    public String getHospitalName() { return hospitalName; }
    public void setHospitalName(String hospitalName) { this.hospitalName = hospitalName; }

    public String getHospitalAddress() { return hospitalAddress; }
    public void setHospitalAddress(String hospitalAddress) { this.hospitalAddress = hospitalAddress; }

    public String getUrgency() { return urgency; }
    public void setUrgency(String urgency) { this.urgency = urgency; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getNeededBefore() { return neededBefore; }
    public void setNeededBefore(LocalDateTime neededBefore) { this.neededBefore = neededBefore; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
