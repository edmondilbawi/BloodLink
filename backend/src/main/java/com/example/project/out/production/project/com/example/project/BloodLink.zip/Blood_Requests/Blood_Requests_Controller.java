package com.example.project.Blood_Requests;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/Blood_Requests")
public class Blood_Requests_Controller {

    private final Blood_Requests_Repository repo;

    public Blood_Requests_Controller(Blood_Requests_Repository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Blood_Requests_Model> all() {
        return repo.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Blood_Requests_Model create(@Valid @RequestBody Blood_Requests_Model request) {
        return repo.save(request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        repo.deleteById(id);
    }
}
