package com.example.project.Donor_Profiles;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Donor_Profiles_Repository extends JpaRepository<Donor_Profiles_Model, Long> {
}
