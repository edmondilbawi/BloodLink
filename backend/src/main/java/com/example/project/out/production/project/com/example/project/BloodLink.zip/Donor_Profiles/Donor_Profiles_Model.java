package com.example.project.Donor_Profiles;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.sql.Timestamp;
import java.util.Date;

@Entity
public class Donor_Profiles_Model  {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long donorId;

    @NotNull
    private Date date_of_birth;

    @NotNull
    private Boolean is_verified;

    @Min(0)
    private int radius_km;
    
    @NotBlank
    private String availability_status;

    @NotNull
    @PastOrPresent
    private Timestamp unavailable_until;

    @NotNull
    @PastOrPresent
    private Timestamp last_donation_at;

    @NotNull
    @PastOrPresent
    private Timestamp cooldown_ends_at;

    @NotNull
    @PastOrPresent
    private Timestamp dnd_until;

    @PastOrPresent
    private Timestamp created_at;

    public Donor_Profiles_Model() {}

    public Donor_Profiles_Model(Long donorId , Date date_of_birth,Boolean is_verified, String availability_status,
                      Timestamp unavailable_until , Timestamp last_donation_at, Timestamp cooldown_ends_at,
                                int radius_km, Timestamp dnd_until) {
        this.donorId = donorId;
        this.date_of_birth = date_of_birth;
        this.is_verified = is_verified;
        this.availability_status = availability_status;
        this.unavailable_until = unavailable_until;
        this.last_donation_at = last_donation_at;
        this.cooldown_ends_at = cooldown_ends_at;
        this.radius_km = radius_km;
        this.dnd_until = dnd_until;
        created_at = new Timestamp(System.currentTimeMillis());
    }

    @PrePersist
    protected void onCreate() {
        if (created_at == null) {
            created_at = new Timestamp(System.currentTimeMillis());
        }
    }



    public Long getDonorId() {return donorId;}
    public void setDonorId(Long donorId) {this.donorId = donorId;}
    public Date getDate_of_birth() {return date_of_birth;}
    public void setDate_of_birth(Date date_of_birth) {this.date_of_birth = date_of_birth;}
    public boolean getIs_verified() {return is_verified;}
    public void setIs_verified(boolean verified) {is_verified = verified;}
    public String getAvailability_status() {return availability_status;}
    public void setAvailability_status(String availability_status) {this.availability_status = availability_status;}
    public Timestamp getUnavailable_until() {return unavailable_until;}
    public void setUnavailable_until(Timestamp unavailable_until) {this.unavailable_until = unavailable_until;}
    public Timestamp getLast_donation_at() {return last_donation_at;}
    public void setLast_donation_at(Timestamp last_donation_at) {this.last_donation_at = last_donation_at;}
    public Timestamp getCooldown_ends_at() {return cooldown_ends_at;}
    public void setCooldown_ends_at(Timestamp cooldown_ends_at) {this.cooldown_ends_at = cooldown_ends_at;}
    public int getRadius_km() {return radius_km;}
    public void setRadius_km(int radius_km) {this.radius_km = radius_km;}
    public Timestamp getDnd_until() {return dnd_until;}
    public void setDnd_until(Timestamp dnd_until) {this.dnd_until = dnd_until;}
    public Timestamp getCreatedAt() { return created_at; }
    public void setCreatedAt(Timestamp created_at) { this.created_at = created_at; }
}
