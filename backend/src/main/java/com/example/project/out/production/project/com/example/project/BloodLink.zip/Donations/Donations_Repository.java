package com.example.project.Donations;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Donations_Repository  extends JpaRepository<Donations_Model, Long> {
}
