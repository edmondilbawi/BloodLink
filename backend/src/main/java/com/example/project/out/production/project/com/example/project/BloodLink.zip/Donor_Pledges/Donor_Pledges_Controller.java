package com.example.project.Donor_Pledges;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/Donor_Pledges")
public class Donor_Pledges_Controller {
    private final Donor_Pledges_Repository repo;

    public Donor_Pledges_Controller(Donor_Pledges_Repository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Donor_Pledges_Model> all() {
        return repo.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Donor_Pledges_Model create(@Valid @RequestBody Donor_Pledges_Model pledge) {
        return repo.save(pledge);
    }

    @DeleteMapping("/{pledge_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable("pledge_id") Long pledgeId) {
        repo.deleteById(pledgeId);
    }
}
