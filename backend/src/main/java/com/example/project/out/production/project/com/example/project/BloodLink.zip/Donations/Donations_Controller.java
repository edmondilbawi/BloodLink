package com.example.project.Donations;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/Donations")
public class Donations_Controller {
    private final Donations_Repository repo;

    public Donations_Controller(Donations_Repository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Donations_Model> all() {
        return repo.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Donations_Model create(@Valid @RequestBody Donations_Model donation) {
        return repo.save(donation);
    }

    @DeleteMapping("/{donor_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable("donor_id") Long donorId) {
        repo.deleteById(donorId);
    }
}
